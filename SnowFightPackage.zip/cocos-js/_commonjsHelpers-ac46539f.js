System.register([],(function(t){"use strict";return{execute:function(){t("c",(function(t,e){return t(e={exports:{}},e.exports),e.exports}))}}}));
